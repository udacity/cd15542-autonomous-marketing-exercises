# Campaign Brief — Momentum Launch (Trimmed)

A shortened version of `sa-momentum-launch-brief.md` — short enough to read
at a glance, still enough to generate real headlines from.

**Brand:** Solstice Active

## Product

Momentum Collection leggings: high-waist, four-way stretch, squat-proof
opacity, sweat-tested moisture-wicking fabric.

## Audience

Women 25–40 who train 3+ times a week and want the leggings to also work
for errands right after.

## Offer

20% off, first 10 days.

## Seed keywords

- High waist leggings squat proof
- Four way stretch leggings
- Workout leggings that don't roll down

## Landing page

`solsticeactive.com/momentum`
