# Oversized-copy test case — validator rejection path

Demonstrates `sa_check_copy.py` rejecting copy that exceeds the character
limit, not just validating copy that already fits.

## Intentionally-too-long headline (limit: 30 chars)

```
The Leggings That Never Roll Down During Your Workout
```

Run it:

```bash
printf '%s' "The Leggings That Never Roll Down During Your Workout" \
  | python3 .claude/skills/sa-google-rsa-best-practices/scripts/sa_check_copy.py --field headline --stdin
```

Expected result: `OVER by 23 characters — 53/30. Trim 23.` (exit code 1)

**In-voice rewrite that passes** (26 chars):

```
Leggings That Never Roll
```

## Intentionally-too-long description (limit: 90 chars)

```
Our high-waist Momentum leggings feature four-way stretch fabric that is fully squat-proof and sweat-tested for every workout you throw at it.
```

Run it:

```bash
printf '%s' "Our high-waist Momentum leggings feature four-way stretch fabric that is fully squat-proof and sweat-tested for every workout you throw at it." \
  | python3 .claude/skills/sa-google-rsa-best-practices/scripts/sa_check_copy.py --field description --stdin
```

Expected result: OVER — trim to fit before it ships.
